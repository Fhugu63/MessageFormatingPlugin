package io.papermc.testplugin

import io.papermc.paper.plugin.loader.PluginClasspathBuilder
import io.papermc.paper.plugin.loader.PluginLoader
import io.papermc.paper.plugin.loader.library.impl.JarLibrary
import io.papermc.paper.plugin.loader.library.impl.MavenLibraryResolver
import org.eclipse.aether.repository.RemoteRepository
import java.nio.file.Path


class TestPluginLoader : PluginLoader {
    override fun classloader(classpathBuilder: PluginClasspathBuilder) {
        classpathBuilder.addLibrary(JarLibrary(Path.of("dependency.jar")))

        val resolver = MavenLibraryResolver()
        //resolver.addDependency(Dependency(DefaultArtifact("com.example:example:version"), null))
        resolver.addRepository(
            RemoteRepository.Builder(
                "paper",
                "default",
                "https://repo.papermc.io/repository/maven-public/"
            ).build()
        )

        classpathBuilder.addLibrary(resolver)
    }
}