package io.papermc.testplugin

import net.kyori.adventure.text.Component
import net.kyori.adventure.text.format.Style
import net.kyori.adventure.text.format.TextColor
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
import org.bukkit.Bukkit
import org.bukkit.command.Command
import org.bukkit.command.CommandSender
import org.bukkit.configuration.file.YamlConfiguration
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.plugin.java.JavaPlugin
import java.io.File


class MessageFormatingPlugin() : JavaPlugin(), Listener {
    lateinit var fileMessages: String

    /* val supportedColors = mapOf(
        Pair("&w",TextColor.color(255, 255, 255)),
        Pair("&g",TextColor.color(200, 200, 200)),
        Pair("&r",TextColor.color(255, 0, 0)),
        Pair("&g",TextColor.color(0, 255, 0)),
        Pair("&b",TextColor.color(0, 0, 255)),
        Pair("&dg",TextColor.color(0, 102, 0)),
        Pair("&o",TextColor.color(255, 128, 0))
    ) */

    override fun onEnable() {
        /* saveResource("config.yml", /* replace */ false);

        val file: File = File(this.getDataFolder(), "messages.txt")
        //val config = YamlConfiguration.loadConfiguration(file)

// Work with config here
        //config.save(file)

        fileMessages = file.readText()

        //println(fileMessages)
        server.sendMessage(Component.text(fileMessages))

        // You can also use this for configuration files:
        saveDefaultConfig();*/

        Bukkit.getPluginManager().registerEvents(this, this)

        this.getCommand("testplugin")?.setExecutor(this)

        //this.server.commandMap.co
    }

    override fun onCommand(sender: CommandSender, command: Command, label: String, args: Array<out String>): Boolean {
        when (command.name.lowercase()) {
            "reload" -> {
                //sender.sendMessage(Component.text("Выполнение команды reload классическим способом!"))
                server.sendMessage(Component.text(fileMessages))
                // Добавьте логику перезагрузки здесь
                return true
            }
            "standart_text" -> {

                    sender.sendMessage(Component.text("Вызвана подкоманда /testplugin reload"))
                    sender.sendMessage(Component.text("Выполнение команды tphere классическим способом!"))
                    var text = ""
                    for (i in 0..args.lastIndex) {
                        text += args[i] + " "
                    }
                    server.sendMessage(Component.text(text))
                //server.sendMessage(Component.text(fileMessages))

                return true
            }
            "formated_text" -> {

                //sender.sendMessage(Component.text("Вызвана подкоманда /testplugin reload"))
                sender.sendMessage(Component.text("Выполнение команды tphere классическим способом!"))
                var text = ""
                var nextStroka = false

                for (i in 3..args.lastIndex) {
                    if (args[i] == "/n") {
                        nextStroka = true
                        text += args[i] + " "
                    } else {
                        text += args[i] + " "
                    }
                }

                if (nextStroka) {
                    var textWithNextSroka = text.split("/n ")
                    for (i1 in 0..textWithNextSroka.lastIndex) {
                        server.sendMessage(
                            Component.text(
                                textWithNextSroka[i1],
                                Style.style(TextColor.color(args[0].toInt(), args[1].toInt(), args[2].toInt()))
                            )
                        )
                    }
                } else {
                    server.sendMessage(
                        Component.text(
                            text,
                            Style.style(TextColor.color(args[0].toInt(), args[1].toInt(), args[2].toInt()))
                        )
                    )
                }


                //server.command

                nextStroka = false

                return true
            }
            "clfw_text" -> {

                //sender.sendMessage(Component.text("Вызвана подкоманда /testplugin reload"))
                //sender.sendMessage(Component.text("Выполнение команды tphere классическим способом!"))
                var text = ""
                var nextStroka = false

                for (i in 0..args.lastIndex) {
                    if (args[i] == "/n") {
                        nextStroka = true
                        text += args[i] + " "
                    } else {
                        text += args[i] + " "
                    }
                }

                val coloredComponent = LegacyComponentSerializer.legacyAmpersand().deserialize(text)

                if (nextStroka) {
                    var textWithNextSroka = text.split("/n ")
                    for (i1 in 0..textWithNextSroka.lastIndex) {
                        val coloredComponent = LegacyComponentSerializer.legacyAmpersand().deserialize(textWithNextSroka[i1])
                        server.sendMessage(
                            coloredComponent
                        )
                    }
                } else {
                    server.sendMessage(
                        coloredComponent
                    )
                }

                //server.sendMessage(coloredComponent)

                //server.command

                nextStroka = false

                return true
            }
            // Добавьте другие подкоманды
            // Добавьте другие подкоманды
        }


        return false
    }

    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        event.getPlayer().sendMessage(Component.text("Hello, " + event.getPlayer().getName() + "!"));
    }
}